package org.zkoss.zk;

import java.lang.String;

public final class Version {
  public static final String UID = "10.2.1";

  public static final String RELEASE = "10.2.1";

  private Version() {
  }
}
